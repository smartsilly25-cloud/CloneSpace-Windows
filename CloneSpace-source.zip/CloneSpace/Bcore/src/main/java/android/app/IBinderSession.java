package android.app;

/**
 * Compile-time stub for the hidden Android 16 type android.app.IBinderSession.
 * At runtime the framework's real class is always loaded first, so this stub is ignored
 * on Android 16+. It only exists so ServiceConnectionDelegate can declare the new
 * IServiceConnection.connected(ComponentName, IBinder, IBinderSession, boolean) method.
 */
public interface IBinderSession {
}
